/**********************************************************************
 * Cours : INF1010
 * Travail pratique 5
 * Nom: gestionnaireMembres.cpp
 * Auteurs:		 Lotfi		Meklati      1953909
 *			     Mathieu	Bussi�res    1882012
 * Equipe : 17
 * Groupe : 03
 **********************************************************************/

#include "GestionnaireMembres.h"
#include <numeric>

void GestionnaireMembres::assignerBillet(Billet* billet, const string& nomMembre, double rabaisCoupon)
{
	Membre* membre = conteneur_[nomMembre];

	if (membre == nullptr) {
		delete billet;
		return;
	}

	double prix = billet->getPrix();

	if (auto solde = dynamic_cast<Solde*>(billet)) {
		prix = solde->getPrixBase();
	}

	
	prix -= rabaisCoupon;
	

	if (auto membrePremium = dynamic_cast<MembrePremium*>(membre)) {
		double rabais = 0.005 * membrePremium->getpointsCumulee() / 1000;
		if (rabais > 0.1)
			rabais = 0.1;

		prix *= (1 - rabais);
	}

	billet->setPrix(prix);
	membre->ajouterBillet(billet);
}


/****************************************************************************
 * Fonction:	GestionnaireMembres::calculerRevenu
 * Description: Calcule la somme des prix des billets poss�d�s par tous les membres
 * Param�tres:	aucun
 * Retour:		(double) revenu total des billets
 ****************************************************************************/
double GestionnaireMembres::calculerRevenu() const
{
	//TODO
	double revenu = 0;
	for_each(conteneur_.begin(), conteneur_.end(), [&revenu]( const pair<string, Membre*>& membre)
	{
		//vecteur cr�� car �crire directement membre.second->getBillets().begin() ou end() ne marche pas
		vector<Billet*> vec = membre.second->getBillets();
		for_each(vec.begin(), vec.end(), [&revenu](Billet* billet)
		{
			revenu += billet->getPrix(); 
		});
	});

	return revenu;
}

/****************************************************************************
 * Fonction:	GestionnaireMembres::calculerNombreBilletsEnSolde
 * Description: Calcule le nombre de billets en solde poss�d�s par tous les membres
 * Param�tres:	aucun
 * Retour:		(int) le nombre total de billets en solde
 ****************************************************************************/
int GestionnaireMembres::calculerNombreBilletsEnSolde() const
{
	//TODO
	int nbBilletsSolde = 0;
	vector<Billet*> billetsCopie;

	//On ajoute les billets de tous les membres au vecteur billetsCopie ...
	for_each(conteneur_.begin(), conteneur_.end(), [&billetsCopie](const pair<string, Membre*>& membre)
	{
		vector<Billet*> vec = membre.second->getBillets();
		billetsCopie.insert(billetsCopie.end(), vec.begin(), vec.end());
	});

	//... puis on compte les billets qui sont sold�s
	for_each(billetsCopie.begin(), billetsCopie.end(), [&nbBilletsSolde](Billet* billet) 
	{
		if (auto d = dynamic_cast<Solde*>(billet)) ++nbBilletsSolde;
	});


	return nbBilletsSolde;
}



/****************************************************************************
 * Fonction:	GestionnaireMembres::getBilletMin
 * Description: Cherche et retourne le billet le moins cher poss�d� par un membre
 * Param�tres:	(string) nomMembre
 * Retour:		(Billet*) pointeur qui pointe vers le billet le moins cher
 ****************************************************************************/
Billet* GestionnaireMembres::getBilletMin(string nomMembre) const
{
	Membre* membreRecherche = nullptr;
	Billet* billet = nullptr;
	for_each(conteneur_.begin(), conteneur_.end(), [&nomMembre, &membreRecherche](const pair<string, Membre*>& membre)
	{
		//On v�rifie si le membre a le m�me nom
		if (membre.second->getNom() == nomMembre) membreRecherche = membre.second;
	});

	if(membreRecherche != nullptr){
			//On copie son vecteur de billets
			vector<Billet*> vec = membreRecherche->getBillets();

			//On fait pointer l'it�rateur vers l'�l�ment le plus petit gr�ce � une comparaison des prix
			vector<Billet*>::iterator it = min_element(vec.begin(), vec.end(), [](Billet* billet1, Billet* billet2)
			{
				if (billet1->getPrix() < billet2->getPrix())
					return true;
				else
					return false;
			});

			//On retourne le billet point� par l'it�rateur
			return *it;

	}
	

	//Retourne nullptr si on a pas trouv� le membre
	return nullptr;

}



/****************************************************************************
 * Fonction:	GestionnaireMembres::getBilletMax
 * Description: Cherche et retourne le billet le plus cher poss�d� par un membre
 * Param�tres:	(string) nomMembre
 * Retour:		(Billet*) pointeur qui pointe vers le billet le plus cher
 ****************************************************************************/
Billet* GestionnaireMembres::getBilletMax(string nomMembre) const
{
	Membre* membreRecherche = nullptr;
	Billet* billet = nullptr;
	for_each(conteneur_.begin(), conteneur_.end(), [&nomMembre, &membreRecherche](const pair<string, Membre*>& membre)
	{
		//On v�rifie si le membre a le m�me nom
		if (membre.second->getNom() == nomMembre) membreRecherche = membre.second;
	});

	if (membreRecherche != nullptr) {
		//On copie son vecteur de billets
		vector<Billet*> vec = membreRecherche->getBillets();

		//On fait pointer l'it�rateur vers l'�l�ment le plus petit gr�ce � une comparaison des prix
		vector<Billet*>::iterator it = max_element(vec.begin(), vec.end(), [](Billet* billet1, Billet* billet2)
		{
			if (billet2->getPrix() > billet1->getPrix())
				return true;
			else
				return false;
		});

		//On retourne le billet point� par l'it�rateur
		return *it;

	}


	//Retourne nullptr si on a pas trouv� le membre
	return nullptr;

}

/****************************************************************************
 * Fonction:	GestionnaireMembres::trouverBilletParIntervallle
 * Description: Retourne un vecteur de billets poss�d�s par un membre compris dans l'intervalle de prix pass�s en param�tres
 * Param�tres:	(Membre*) membre, (double) prixInf, (double) prixSup
 * Retour:		(vector<Billet*>) vecteur de billets compris dans l'intervalle
 ****************************************************************************/
vector<Billet*> GestionnaireMembres::trouverBilletParIntervallle(Membre* membre, double prixInf, double prixSup) const 
{
	IntervallePrixBillet intervalle(prixInf, prixSup);
	
	vector<Billet*> billets = membre->getBillets(), billetsIntervalle;

	//On copie les billets qui satisfont le foncteur "IntervallePrixBillet"
	copy_if(billets.begin(), billets.end(), back_inserter(billetsIntervalle), intervalle);
	return billetsIntervalle;
}

/****************************************************************************
 * Fonction:	GestionnaireMembres::afficher
 * Description: Affiche les informations de tous les membres
 * Param�tres:	(ostream&) o
 * Retour:		aucun
 ****************************************************************************/
void GestionnaireMembres::afficher(ostream& o) const
{
	//TODO
	o << "=================== ETAT ACTUEL DU PROGRAMME ==================\n\n";

	for_each(conteneur_.begin(), conteneur_.end(), [&o](const pair<string, Membre*>& membre)
	{
		membre.second->afficher(o);
	});
}
